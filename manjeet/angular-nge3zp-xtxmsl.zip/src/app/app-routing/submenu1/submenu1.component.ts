import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submenu1',
  templateUrl: './submenu1.component.html',
  styleUrls: ['./submenu1.component.css']
})
export class Submenu1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}