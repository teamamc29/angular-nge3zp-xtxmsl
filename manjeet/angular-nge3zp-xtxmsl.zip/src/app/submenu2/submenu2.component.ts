import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submenu2',
  templateUrl: './submenu2.component.html',
  styleUrls: ['./submenu2.component.css']
})
export class Submenu2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}